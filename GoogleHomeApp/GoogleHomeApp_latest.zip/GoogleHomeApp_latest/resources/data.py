appPackageName='com.google.android.apps.chromecast.app'
appActivityName='com.google.android.apps.chromecast.app.DiscoveryActivity'
appWaitPackageName='com.google.android.apps.chromecast.app'
appWaitActivityName='com.google.android.apps.chromecast.app.firstlaunch.FirstLaunchWizardActivity'
wifissid='TP-Link_7632'
wifiPassword='marvel@1920'
FriendlyName="Lyric Speaker Box 9b3eed"
AccountName='kiran kumarc'

LinkingDeviceName='Lyric Speaker Box'

portnumber='COM4'